package com.example.dell.mymultiworld;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class operatingsystem extends AppCompatActivity {
    private oslibrary nosLibrary = new oslibrary();

    private TextView nScoreView;
    private TextView nQuestionView;
    private Button nChoice1;
    private Button nChoice2;
    private Button nChoice3;
    private Button nChoice4;
    private Button nnext;
    //  private TextView nAnswerView;
    private int nScore = 0;
    private int nQuestionNumber = 0;
    private String nAnswer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_operatingsystem);
        nScoreView = (TextView) findViewById(R.id.Score);
        nQuestionView = (TextView) findViewById(R.id.question);
        nChoice1 = (Button) findViewById(R.id.choice1);
        nChoice2 = (Button) findViewById(R.id.choice2);
        nChoice3 = (Button) findViewById(R.id.choice3);
        nChoice4 = (Button) findViewById(R.id.choice4);
        nnext=(Button)findViewById(R.id.Next);
        //  nAnswerView = (TextView) findViewById(R.id.answer);
        updatequestion();

        nChoice1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (nChoice1.getText() == nAnswer) {

                    nScore = nScore + 1;
                    Toast.makeText(operatingsystem.this, "Welldone !! Keep it up :)", Toast.LENGTH_LONG).show();
                    updateScore(nScore);
                    // nAnswerView.setText(nAnswer);
                    nChoice1.setBackgroundResource(R.color.colorGreen);
                }
                else {
                    Toast.makeText(operatingsystem.this, "Oops !! Better luck next time :(", Toast.LENGTH_LONG).show();
                    //  nAnswerView.setText(nAnswer);
                    nChoice1.setBackgroundResource(R.color.colorRed);
                    if(nChoice2.getText()==nAnswer){
                        nChoice2.setBackgroundResource(R.color.colorGreen);
                    }

                    if(nChoice3.getText()==nAnswer){
                        nChoice3.setBackgroundResource(R.color.colorGreen);
                    }

                    if(nChoice4.getText()==nAnswer){
                        nChoice4.setBackgroundResource(R.color.colorGreen);
                    }
                }

            }
        });



        nnext.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                if(nQuestionNumber<=9){
                    updatequestion();
                    nChoice2.setBackgroundResource(R.color.lightGrey);
                    nChoice1.setBackgroundResource(R.color.lightGrey);
                    nChoice3.setBackgroundResource(R.color.lightGrey);
                    nChoice4.setBackgroundResource(R.color.lightGrey);}

                else{
                    Intent intent5 = new Intent(operatingsystem.this, Main4Activity.class);
                    intent5.putExtra("Score",nScoreView.getText().toString());
                    startActivity(intent5);

                }
                // nAnswerView.setText("   ");
            }
        });

        nChoice2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (nChoice2.getText() == nAnswer) {
                    nScore = nScore + 1;
                    updateScore(nScore);
                    // nAnswerView.setText(" ");
                    nChoice2.setBackgroundResource(R.color.colorGreen);

                    Toast.makeText(operatingsystem.this, "Welldone !! Keep it up :)", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(operatingsystem.this, "Oops !! Better luck next time :(", Toast.LENGTH_LONG).show();
                    nChoice2.setBackgroundResource(R.color.colorRed);
                    if(nChoice1.getText()==nAnswer){
                        nChoice1.setBackgroundResource(R.color.colorGreen);
                    }

                    if(nChoice3.getText()==nAnswer){
                        nChoice3.setBackgroundResource(R.color.colorGreen);
                    }

                    if(nChoice4.getText()==nAnswer){
                        nChoice4.setBackgroundResource(R.color.colorGreen);
                    }

                    //  nAnswerView.setText(nAnswer);

                }
            }
        });
        nChoice3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (nChoice3.getText() == nAnswer) {
                    nScore = nScore + 1;
                    // nAnswerView.setText(" ");
                    updateScore(nScore);
                    nChoice3.setBackgroundResource(R.color.colorGreen);

                    Toast.makeText(operatingsystem.this, "Welldone !! Keep it up :)", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(operatingsystem.this, "Oops !! Better luck next time :(", Toast.LENGTH_LONG).show();
                    nChoice3.setBackgroundResource(R.color.colorRed);
                    if(nChoice1.getText()==nAnswer){
                        nChoice1.setBackgroundResource(R.color.colorGreen);
                    }

                    if(nChoice2.getText()==nAnswer){
                        nChoice2.setBackgroundResource(R.color.colorGreen);
                    }

                    if(nChoice4.getText()==nAnswer){
                        nChoice4.setBackgroundResource(R.color.colorGreen);
                    }

                    // nAnswerView.setText(nAnswer);

                }
            }
        });
        nChoice4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (nChoice4.getText() == nAnswer) {
                    nScore = nScore + 1;
                    updateScore(nScore);
                    //  nAnswerView.setText(" ");
                    nChoice4.setBackgroundResource(R.color.colorGreen);

                    Toast.makeText(operatingsystem.this, "Welldone !! Keep it up :)", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(operatingsystem.this, "Oops !! Better luck next time :(", Toast.LENGTH_LONG).show();
                    nChoice4.setBackgroundResource(R.color.colorRed);
                    if(nChoice1.getText()==nAnswer){
                        nChoice1.setBackgroundResource(R.color.colorGreen);
                    }

                    if(nChoice2.getText()==nAnswer){
                        nChoice2.setBackgroundResource(R.color.colorGreen);
                    }

                    if(nChoice3.getText()==nAnswer){
                        nChoice3.setBackgroundResource(R.color.colorGreen);
                    }

//                    nAnswerView.setText(nAnswer);

                }
            }
        });

    }

    private void updatequestion() {

        nQuestionView.setText(nosLibrary.getQuestion(nQuestionNumber));
        nChoice1.setText(nosLibrary.getChoice1(nQuestionNumber));
        nChoice2.setText(nosLibrary.getChoice2(nQuestionNumber));
        nChoice3.setText(nosLibrary.getChoice3(nQuestionNumber));
        nChoice4.setText(nosLibrary.getChoice4(nQuestionNumber));
        nAnswer = nosLibrary.getCorrectAnswers(nQuestionNumber);
        nQuestionNumber++;
    }
    private void updateScore(int b) {
        nScoreView.setText("" + nScore);
    }
}

class oslibrary {
    private String nQuestions[] = {"A ..... is a windows component that is designed to store other components so these can be organized efficiently?",
            "A system program that combines the separately compiled modules of a program into a form suitable for execution",
            "The strategy of allowing processes that are logically runnable to be temporarily suspended is called",
            "The LRU algorithm",
            "Which of the following systems software does the job of merging the records from two files into one?",
            "Which of the following instruction steps, would be written within the diamond-shaped box, of a flowchart?",
            "In virtual memory systems, Dynamic address translation",
            "In which addressing mode the effective address of the operand is the contents of a register specified in the instruction and " +
                    "after accessing the operand, the contents of this register is incremented to point to the next item in the list?",
               "What is the name of the operating system for the laptop computer called MacLite?" ,
              "What is the name given to the values that are automatically provided by software to reduce keystrokes and improve a computer user's productivity?"};
    private String nCorrectAnswers[] = {"Folder", "linking loader", "preemptive scheduling", "pages out pages that have been least used recently","Utility program","IS A<10","is the hardware necessary to implement paging","auto increment","OZ","Default values"};
    private String nChoices[][] = {{"Document", "Window", "Folder", "All of above"},
            {"assembler", "linking loader", "cross compiler", "load and go"},
            {"preemptive scheduling", "non preemptive scheduling", "first come first served", "shortest job first"},
            {"pages out pages that have been used recently", "pages out pages that have not been used recently", "pages out pages that have been least used recently", "None of the above"},
            {"Security software","Utility program","Networking software","Documentation system"},
            {"S = B - C","IS A<10","DATA X,4Z","none of above"},
            {"is the hardware necessary to implement paging","stores pages at a specific location on disk","is part of the operating system paging algorithm","is useless when swapping is used"},
            {"index addressing","indirect addressing","auto increment","auto decrement"},
            {"Windows","DOS","MS-DOS","OZ"},
            {"Defined values","Fixed values","Default values","Special values"}};

    public String getQuestion(int a) {
        String question = nQuestions[a];
        return question;
    }

    public String getChoice1(int a) {
        String choice1 = nChoices[a][0];
        return choice1;
    }

    public String getChoice2(int a) {
        String choice2 = nChoices[a][1];
        return choice2;
    }

    public String getChoice3(int a) {
        String choice3 = nChoices[a][2];
        return choice3;
    }

    public String getChoice4(int a) {
        String choice4 = nChoices[a][3];
        return choice4;
    }

    public String getCorrectAnswers(int a) {
        String answer = nCorrectAnswers[a];
        return answer;
    }
}
