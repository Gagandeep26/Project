package com.example.dell.mymultiworld;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class cg extends AppCompatActivity {
    private cglibrary ncgLibrary = new cglibrary();

    private TextView nScoreView;
    private TextView nQuestionView;
    private Button nChoice1;
    private Button nChoice2;
    private Button nChoice3;
    private Button nChoice4;
    private Button nnext;
    //  private TextView nAnswerView;
    private int nScore = 0;
    private int nQuestionNumber = 0;
    private String nAnswer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cg);
        nScoreView = (TextView) findViewById(R.id.Score);
        nQuestionView = (TextView) findViewById(R.id.question);
        nChoice1 = (Button) findViewById(R.id.choice1);
        nChoice2 = (Button) findViewById(R.id.choice2);
        nChoice3 = (Button) findViewById(R.id.choice3);
        nChoice4 = (Button) findViewById(R.id.choice4);
        nnext=(Button)findViewById(R.id.Next);
        //  nAnswerView = (TextView) findViewById(R.id.answer);
        updatequestion();

        nChoice1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (nChoice1.getText() == nAnswer) {

                    nScore = nScore + 1;
                    Toast.makeText(cg.this, "Welldone !! Keep it up :)", Toast.LENGTH_LONG).show();
                    updateScore(nScore);
                    // nAnswerView.setText(nAnswer);
                    nChoice1.setBackgroundResource(R.color.colorGreen);
                }
                else {
                    Toast.makeText(cg.this, "Oops !! Better luck next time :(", Toast.LENGTH_LONG).show();
                    //  nAnswerView.setText(nAnswer);
                    nChoice1.setBackgroundResource(R.color.colorRed);
                    if(nChoice2.getText()==nAnswer){
                        nChoice2.setBackgroundResource(R.color.colorGreen);
                    }

                    if(nChoice3.getText()==nAnswer){
                        nChoice3.setBackgroundResource(R.color.colorGreen);
                    }

                    if(nChoice4.getText()==nAnswer){
                        nChoice4.setBackgroundResource(R.color.colorGreen);
                    }
                }

            }
        });



        nnext.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                if(nQuestionNumber<=9){
                    updatequestion();
                    nChoice2.setBackgroundResource(R.color.lightGrey);
                    nChoice1.setBackgroundResource(R.color.lightGrey);
                    nChoice3.setBackgroundResource(R.color.lightGrey);
                    nChoice4.setBackgroundResource(R.color.lightGrey);}

                else{
                    Intent intent5 = new Intent(cg.this, Main4Activity.class);
                    intent5.putExtra("Score",nScoreView.getText().toString());
                    startActivity(intent5);

                }
                // nAnswerView.setText("   ");
            }
        });

        nChoice2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (nChoice2.getText() == nAnswer) {
                    nScore = nScore + 1;
                    updateScore(nScore);
                    // nAnswerView.setText(" ");
                    nChoice2.setBackgroundResource(R.color.colorGreen);

                    Toast.makeText(cg.this, "Welldone !! Keep it up :)", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(cg.this, "Oops !! Better luck next time :(", Toast.LENGTH_LONG).show();
                    nChoice2.setBackgroundResource(R.color.colorRed);
                    if(nChoice1.getText()==nAnswer){
                        nChoice1.setBackgroundResource(R.color.colorGreen);
                    }

                    if(nChoice3.getText()==nAnswer){
                        nChoice3.setBackgroundResource(R.color.colorGreen);
                    }

                    if(nChoice4.getText()==nAnswer){
                        nChoice4.setBackgroundResource(R.color.colorGreen);
                    }

                    //  nAnswerView.setText(nAnswer);

                }
            }
        });
        nChoice3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (nChoice3.getText() == nAnswer) {
                    nScore = nScore + 1;
                    // nAnswerView.setText(" ");
                    updateScore(nScore);
                    nChoice3.setBackgroundResource(R.color.colorGreen);

                    Toast.makeText(cg.this, "Welldone !! Keep it up :)", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(cg.this, "Oops !! Better luck next time :(", Toast.LENGTH_LONG).show();
                    nChoice3.setBackgroundResource(R.color.colorRed);
                    if(nChoice1.getText()==nAnswer){
                        nChoice1.setBackgroundResource(R.color.colorGreen);
                    }

                    if(nChoice2.getText()==nAnswer){
                        nChoice2.setBackgroundResource(R.color.colorGreen);
                    }

                    if(nChoice4.getText()==nAnswer){
                        nChoice4.setBackgroundResource(R.color.colorGreen);
                    }

                    // nAnswerView.setText(nAnswer);

                }
            }
        });
        nChoice4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (nChoice4.getText() == nAnswer) {
                    nScore = nScore + 1;
                    updateScore(nScore);
                    //  nAnswerView.setText(" ");
                    nChoice4.setBackgroundResource(R.color.colorGreen);

                    Toast.makeText(cg.this, "Welldone !! Keep it up :)", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(cg.this, "Oops !! Better luck next time :(", Toast.LENGTH_LONG).show();
                    nChoice4.setBackgroundResource(R.color.colorRed);
                    if(nChoice1.getText()==nAnswer){
                        nChoice1.setBackgroundResource(R.color.colorGreen);
                    }

                    if(nChoice2.getText()==nAnswer){
                        nChoice2.setBackgroundResource(R.color.colorGreen);
                    }

                    if(nChoice3.getText()==nAnswer){
                        nChoice3.setBackgroundResource(R.color.colorGreen);
                    }

//                    nAnswerView.setText(nAnswer);

                }
            }
        });

    }

    private void updatequestion() {

        nQuestionView.setText(ncgLibrary.getQuestion(nQuestionNumber));
        nChoice1.setText(ncgLibrary.getChoice1(nQuestionNumber));
        nChoice2.setText(ncgLibrary.getChoice2(nQuestionNumber));
        nChoice3.setText(ncgLibrary.getChoice3(nQuestionNumber));
        nChoice4.setText(ncgLibrary.getChoice4(nQuestionNumber));
        nAnswer = ncgLibrary.getCorrectAnswers(nQuestionNumber);
        nQuestionNumber++;
    }





    private void updateScore(int b) {
        nScoreView.setText("" + nScore);
    }
}

class cglibrary {
    private String nQuestions[] = {"...................... is the ratio of horizontal points to vertical points necessary to produce equal length\n" +
            "lines in both direction. ",
            " In random scan display, the frame buffer holds ...................... ",
            " The amount of light emitted by the phosphor coating depends on the? ",
            "The transformation in which an object is moved from one position to another in circular path around a specified pivot point is called",
    "The anti-aliasing technique which allows shift of 114, 112 and 3/4 of a pixel diameter enabling a closer path of a line is",
    "In Bresenham's algorithm, while generating a circle , it is easy to generate?",
    " Which of the following clipping algorithm follows the Divide and Conquer strategy?",
    "A line with endpoints codes as 0000 and 0100 is ?",
    " Reflection of a point about x-axis, followed by a counter-clockwise rotation of 90 degree, is equivalent to reflection about the line ?",
    "Choose the incorrect statement from the following about the basic ray tracing technique used in image synthesis ?"};
    private String nCorrectAnswers[] = {"Aspect Ratio", "Line drawing commands", " Number of electrons striking the screen ", "Rotation","pixel phasing","One octant first and other by successive reflection","Midpoint algorithm","Partially invisible","x = y","In this technique rays are cast from the light source to the object in the scene"};
    private String nChoices[][] = {{"Dot Pitch", "Resolution", "Aspect Ratio", "Height-Width Ratio "},
            {"Line drawing commands", "Scanning instructions", "Image Resolution"," Intensity information"},
            {" Number of electrons striking the screen ", "Speed of electrons striking the screen", "Distance from the cathode to the screen", "None of above "},
            {"Rotation", "Shearing", "Translation", " Scaling"},
            {"pixel phasing","filtering","intensity compensation","sampling technique"},
            {"One octant first and other by successive reflection","One octant first and other by successive rotation","One octant first and other by successive translation","All octants"},
            {"4-bit algorithm","Midpoint algorithm","Cyrus break algorithm","Cohen- Sutherland algorithm"},
            {"Partially invisible","Completely visible","Completely invisible","Trivially invisible"},
            {"x = - y","y = - x","x = y","x + y = 1"},
            {"In this technique rays are cast from the eye point through every pixel on the screen","In this technique, viewing transformation are not supplied to the scene prior to rendering","This technique removes hidden surfaces.","In this technique rays are cast from the light source to the object in the scene"}};

    public String getQuestion(int a) {
        String question = nQuestions[a];
        return question;
    }

    public String getChoice1(int a) {
        String choice1 = nChoices[a][0];
        return choice1;
    }

    public String getChoice2(int a) {
        String choice2 = nChoices[a][1];
        return choice2;
    }

    public String getChoice3(int a) {
        String choice3 = nChoices[a][2];
        return choice3;
    }

    public String getChoice4(int a) {
        String choice4 = nChoices[a][3];
        return choice4;
    }

    public String getCorrectAnswers(int a) {
        String answer = nCorrectAnswers[a];
        return answer;
    }
}
