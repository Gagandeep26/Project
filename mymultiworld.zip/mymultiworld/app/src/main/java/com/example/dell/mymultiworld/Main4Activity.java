package com.example.dell.mymultiworld;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;

public class Main4Activity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
  }


    public void Clanguage(View view) {
        Intent intent1 = new Intent(Main4Activity.this, CLanguage.class);
        startActivity(intent1);
    }

    public void java(View view) {
        Intent intent2 = new Intent(Main4Activity.this, Java.class);
        startActivity(intent2);
    }

    public void datastructure(View view) {
        Intent intent3 = new Intent(Main4Activity.this, datastructure.class);
        startActivity(intent3);
    }

    public void operatingsystem(View view) {
        Intent intent3 = new Intent(Main4Activity.this, operatingsystem.class);
        startActivity(intent3);
    }

    public void networking(View view) {
        Intent intent4 = new Intent(Main4Activity.this, networking.class);
        startActivity(intent4);
    }

    public void cplus(View view) {
        Intent intent5 = new Intent(Main4Activity.this, cplus.class);
        startActivity(intent5);
    }

    public void dbms(View view) {
        Intent intent6 = new Intent(Main4Activity.this, dbms.class);
        startActivity(intent6);
    }

    public void cg(View view) {
        Intent intent7 = new Intent(Main4Activity.this, cg.class);
        startActivity(intent7);
    }
}