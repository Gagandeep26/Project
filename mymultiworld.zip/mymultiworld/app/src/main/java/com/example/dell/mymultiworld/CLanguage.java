package com.example.dell.mymultiworld;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class CLanguage extends AppCompatActivity {
    private library nLibrary = new library();

    private TextView nScoreView;
    private TextView nQuestionView;
    private Button nChoice1;
    private Button nChoice2;
    private Button nChoice3;
    private Button nChoice4;
    private Button nnext;
  //  private TextView nAnswerView;
    private int nScore = 0;
    private int nQuestionNumber = 0;
    private String nAnswer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clanguage);
        nScoreView = (TextView) findViewById(R.id.Score);
        nQuestionView = (TextView) findViewById(R.id.question);
        nChoice1 = (Button) findViewById(R.id.choice1);
        nChoice2 = (Button) findViewById(R.id.choice2);
        nChoice3 = (Button) findViewById(R.id.choice3);
        nChoice4 = (Button) findViewById(R.id.choice4);
        nnext=(Button)findViewById(R.id.Next);
      //  nAnswerView = (TextView) findViewById(R.id.answer);
        updatequestion();

        nChoice1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (nChoice1.getText() == nAnswer) {

                    nScore = nScore + 1;
                    Toast.makeText(CLanguage.this, "Welldone !! Keep it up :)", Toast.LENGTH_LONG).show();
                    updateScore(nScore);
                   // nAnswerView.setText(nAnswer);
                    nChoice1.setBackgroundResource(R.color.colorGreen);
                }
                else {
                    Toast.makeText(CLanguage.this, "Oops !! Better luck next time :(", Toast.LENGTH_LONG).show();
                    //  nAnswerView.setText(nAnswer);
                    nChoice1.setBackgroundResource(R.color.colorRed);
                    if(nChoice2.getText()==nAnswer){
                        nChoice2.setBackgroundResource(R.color.colorGreen);
                    }

                    if(nChoice3.getText()==nAnswer){
                        nChoice3.setBackgroundResource(R.color.colorGreen);
                    }

                    if(nChoice4.getText()==nAnswer){
                        nChoice4.setBackgroundResource(R.color.colorGreen);
                    }
                }

            }
        });
        nnext.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                if(nQuestionNumber<=9){
                updatequestion();
                nChoice2.setBackgroundResource(R.color.lightGrey);
                nChoice1.setBackgroundResource(R.color.lightGrey);
                nChoice3.setBackgroundResource(R.color.lightGrey);
                nChoice4.setBackgroundResource(R.color.lightGrey);}

                else{
                    Intent intent5 = new Intent(CLanguage.this, Main4Activity.class);
                    intent5.putExtra("Score",nScoreView.getText().toString());
                    startActivity(intent5);

                }
               // nAnswerView.setText("   ");
            }
        });

        nChoice2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (nChoice2.getText() == nAnswer) {
                    nScore = nScore + 1;
                    updateScore(nScore);
                   // nAnswerView.setText(" ");
                    nChoice2.setBackgroundResource(R.color.colorGreen);

                    Toast.makeText(CLanguage.this, "Welldone !! Keep it up :)", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(CLanguage.this, "Oops !! Better luck next time :(", Toast.LENGTH_LONG).show();
                    nChoice2.setBackgroundResource(R.color.colorRed);
                    if(nChoice1.getText()==nAnswer){
                        nChoice1.setBackgroundResource(R.color.colorGreen);
                    }

                    if(nChoice3.getText()==nAnswer){
                        nChoice3.setBackgroundResource(R.color.colorGreen);
                    }

                    if(nChoice4.getText()==nAnswer){
                        nChoice4.setBackgroundResource(R.color.colorGreen);
                    }

                  //  nAnswerView.setText(nAnswer);

                }
            }
        });
        nChoice3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (nChoice3.getText() == nAnswer) {
                    nScore = nScore + 1;
                   // nAnswerView.setText(" ");
                    updateScore(nScore);
                    nChoice3.setBackgroundResource(R.color.colorGreen);

                    Toast.makeText(CLanguage.this, "Welldone !! Keep it up :)", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(CLanguage.this, "Oops !! Better luck next time :(", Toast.LENGTH_LONG).show();
                    nChoice3.setBackgroundResource(R.color.colorRed);
                    if(nChoice1.getText()==nAnswer){
                        nChoice1.setBackgroundResource(R.color.colorGreen);
                    }

                    if(nChoice2.getText()==nAnswer){
                        nChoice2.setBackgroundResource(R.color.colorGreen);
                    }

                    if(nChoice4.getText()==nAnswer){
                        nChoice4.setBackgroundResource(R.color.colorGreen);
                    }

                   // nAnswerView.setText(nAnswer);

                }
            }
        });
        nChoice4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (nChoice4.getText() == nAnswer) {
                    nScore = nScore + 1;
                    updateScore(nScore);
                  //  nAnswerView.setText(" ");
                    nChoice4.setBackgroundResource(R.color.colorGreen);

                    Toast.makeText(CLanguage.this, "Welldone !! Keep it up :)", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(CLanguage.this, "Oops !! Better luck next time :(", Toast.LENGTH_LONG).show();
                    nChoice4.setBackgroundResource(R.color.colorRed);
                    if(nChoice1.getText()==nAnswer){
                        nChoice1.setBackgroundResource(R.color.colorGreen);
                    }

                    if(nChoice2.getText()==nAnswer){
                        nChoice2.setBackgroundResource(R.color.colorGreen);
                    }

                    if(nChoice3.getText()==nAnswer){
                        nChoice3.setBackgroundResource(R.color.colorGreen);
                    }

//                    nAnswerView.setText(nAnswer);

                }
            }
        });

    }

    private void updatequestion() {

            nQuestionView.setText(nLibrary.getQuestion(nQuestionNumber));
            nChoice1.setText(nLibrary.getChoice1(nQuestionNumber));
            nChoice2.setText(nLibrary.getChoice2(nQuestionNumber));
            nChoice3.setText(nLibrary.getChoice3(nQuestionNumber));
            nChoice4.setText(nLibrary.getChoice4(nQuestionNumber));
            nAnswer = nLibrary.getCorrectAnswers(nQuestionNumber);
            nQuestionNumber++;
        }





    private void updateScore(int b) {
        nScoreView.setText("" + nScore);
    }
}

    class library {
        private String nQuestions[] = {"What does the following command line signify?\n" +
                "       prog1|prog2","void main()\n" +
                "{\n" +
                "char *p = calloc(100, 1);\n" +
                "p = \"welcome\";\n" +
                "printf(\"%s\\n\", p);}\n"
                ,"During preprocessing, the code “#include<stdio.h>” gets replaced by the contents of the file stdio.h.","In the given below code, if a short int value is 5 byte long, then how many times the while loop will get executed?\n" +
                "\n" +
                "#include<stdio.h>\n" +
                "\n" +
                "int main ()\n" +
                "{\n" +
                "   int j = 1;\n" +
                "   while(j <= 300)\n" +
                "   {\n" +
                "      printf(\"%c %d\\n\", j, j);\n" +
                "      j++;\n" +
                "   }\n" +
                "   return 0;\n" +
                "}","The value of j at the end of the execution of the following C program. \n" +
                "\n" +
                "int incr (int i)\n" +
                "{\n" +
                "   static int count = 0;\n" +
                "   count = count + i;\n" +
                "   return (count);\n" +
                "}\n" +
                "main ()\n" +
                "{\n" +
                "   int i,j;\n" +
                "   for (i = 0; i <=4; i++)\n" +
                "      j = incr(i);\n" +
                "}","If you pass an array as an argument to a function, what actually gets passed?",
        "Array can be considered as set of elements stored in consecutive memory locations but having __________.",
        " What is the output of this C code?\n" +
                "\n" +
                "int main()\n" +
                "{\n" +
                "int i = 10;\n" +
                "void *p = &i;\n" +
                "printf(\"%d\\n\", (int)*p);\n" +
                "return 0;\n" +
                "}","If there is any error while opening a file, fopen will return?","Which of the following is a User-defined data type?"};






        private String nCorrectAnswers[] = {"It runs both the programs, pipes output of prog1 to input of prog2", "welcome", "Yes", " 300 times","10","Base address of the array","Same Data Type","Compile time error","NULL","All of the mentioned"};



        private String nChoices[][] = {{"It runs prog1 first, prog2 second","It runs prog2 first, prog1 second",
                "It runs both the programs, pipes output of prog1 to input of prog2",
                 "It runs both the programs, pipes output of prog2 to input of prog1"},
                { "Segmentation fault"," garbage","Error","welcome"},
                {"Yes", "During linking the code “#include<stdio.h>” replaces by stdio.h", "During execution the code “#include<stdio.h>” replaces by stdio.h", "During editing the code “#include<stdio.h>” replaces by stdio.h"},
                {"Unlimited times", "0 times", " 300 times", "5 times"},{"10","4","6","7"},{"First element of the array","Value of elements in array","Address of the last element of array","Base address of the array"},
                {"Different Data Type","None of these","Same Data Type","Same Scope"},
                {"Compile time error","Segmentation fault/runtime crash","10 ","Undefined behaviour"},{" Nothing","EOF","NULL","Depends on compiler"},
                {"typedef int Boolean;","typedef enum {Mon, Tue, Wed, Thu, Fri} Workdays;","struct {char name[10], int age};","All of the mentioned"}};


        public String getQuestion(int a) {
            String question = nQuestions[a];
            return question;
        }

        public String getChoice1(int a) {
            String choice1 = nChoices[a][0];
            return choice1;
        }

        public String getChoice2(int a) {
            String choice2 = nChoices[a][1];
            return choice2;
        }

        public String getChoice3(int a) {
            String choice3 = nChoices[a][2];
            return choice3;
        }

        public String getChoice4(int a) {
            String choice4 = nChoices[a][3];
            return choice4;
        }

        public String getCorrectAnswers(int a) {
            String answer = nCorrectAnswers[a];
            return answer;
        }
    }

