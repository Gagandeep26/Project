package com.example.dell.mymultiworld;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class networking extends AppCompatActivity {
    private netlibrary netLibrary = new netlibrary();

    private TextView nScoreView;
    private TextView nQuestionView;
    private Button nChoice1;
    private Button nChoice2;
    private Button nChoice3;
    private Button nChoice4;
    private Button nnext;
    //  private TextView nAnswerView;
    private int nScore = 0;
    private int nQuestionNumber = 0;
    private String nAnswer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_networking);
        nScoreView = (TextView) findViewById(R.id.Score);
        nQuestionView = (TextView) findViewById(R.id.question);
        nChoice1 = (Button) findViewById(R.id.choice1);
        nChoice2 = (Button) findViewById(R.id.choice2);
        nChoice3 = (Button) findViewById(R.id.choice3);
        nChoice4 = (Button) findViewById(R.id.choice4);
        nnext=(Button)findViewById(R.id.Next);
        //  nAnswerView = (TextView) findViewById(R.id.answer);
        updatequestion();

        nChoice1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (nChoice1.getText() == nAnswer) {

                    nScore = nScore + 1;
                    Toast.makeText(networking.this, "Welldone !! Keep it up :)", Toast.LENGTH_LONG).show();
                    updateScore(nScore);
                    // nAnswerView.setText(nAnswer);
                    nChoice1.setBackgroundResource(R.color.colorGreen);
                }
                else {
                    Toast.makeText(networking.this, "Oops !! Better luck next time :(", Toast.LENGTH_LONG).show();
                    //  nAnswerView.setText(nAnswer);
                    nChoice1.setBackgroundResource(R.color.colorRed);
                    if(nChoice2.getText()==nAnswer){
                        nChoice2.setBackgroundResource(R.color.colorGreen);
                    }

                    if(nChoice3.getText()==nAnswer){
                        nChoice3.setBackgroundResource(R.color.colorGreen);
                    }

                    if(nChoice4.getText()==nAnswer){
                        nChoice4.setBackgroundResource(R.color.colorGreen);
                    }
                }

            }
        });



        nnext.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                if(nQuestionNumber<=9){
                    updatequestion();
                    nChoice2.setBackgroundResource(R.color.lightGrey);
                    nChoice1.setBackgroundResource(R.color.lightGrey);
                    nChoice3.setBackgroundResource(R.color.lightGrey);
                    nChoice4.setBackgroundResource(R.color.lightGrey);}

                else{
                    Intent intent5 = new Intent(networking.this, Main4Activity.class);
                    intent5.putExtra("Score",nScoreView.getText().toString());
                    startActivity(intent5);

                }
                // nAnswerView.setText("   ");
            }
        });

        nChoice2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (nChoice2.getText() == nAnswer) {
                    nScore = nScore + 1;
                    updateScore(nScore);
                    // nAnswerView.setText(" ");
                    nChoice2.setBackgroundResource(R.color.colorGreen);

                    Toast.makeText(networking.this, "Welldone !! Keep it up :)", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(networking.this, "Oops !! Better luck next time :(", Toast.LENGTH_LONG).show();
                    nChoice2.setBackgroundResource(R.color.colorRed);
                    if(nChoice1.getText()==nAnswer){
                        nChoice1.setBackgroundResource(R.color.colorGreen);
                    }

                    if(nChoice3.getText()==nAnswer){
                        nChoice3.setBackgroundResource(R.color.colorGreen);
                    }

                    if(nChoice4.getText()==nAnswer){
                        nChoice4.setBackgroundResource(R.color.colorGreen);
                    }

                    //  nAnswerView.setText(nAnswer);

                }
            }
        });
        nChoice3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (nChoice3.getText() == nAnswer) {
                    nScore = nScore + 1;
                    // nAnswerView.setText(" ");
                    updateScore(nScore);
                    nChoice3.setBackgroundResource(R.color.colorGreen);

                    Toast.makeText(networking.this, "Welldone !! Keep it up :)", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(networking.this, "Oops !! Better luck next time :(", Toast.LENGTH_LONG).show();
                    nChoice3.setBackgroundResource(R.color.colorRed);
                    if(nChoice1.getText()==nAnswer){
                        nChoice1.setBackgroundResource(R.color.colorGreen);
                    }

                    if(nChoice2.getText()==nAnswer){
                        nChoice2.setBackgroundResource(R.color.colorGreen);
                    }

                    if(nChoice4.getText()==nAnswer){
                        nChoice4.setBackgroundResource(R.color.colorGreen);
                    }

                    // nAnswerView.setText(nAnswer);

                }
            }
        });
        nChoice4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (nChoice4.getText() == nAnswer) {
                    nScore = nScore + 1;
                    updateScore(nScore);
                    //  nAnswerView.setText(" ");
                    nChoice4.setBackgroundResource(R.color.colorGreen);

                    Toast.makeText(networking.this, "Welldone !! Keep it up :)", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(networking.this, "Oops !! Better luck next time :(", Toast.LENGTH_LONG).show();
                    nChoice4.setBackgroundResource(R.color.colorRed);
                    if(nChoice1.getText()==nAnswer){
                        nChoice1.setBackgroundResource(R.color.colorGreen);
                    }

                    if(nChoice2.getText()==nAnswer){
                        nChoice2.setBackgroundResource(R.color.colorGreen);
                    }

                    if(nChoice3.getText()==nAnswer){
                        nChoice3.setBackgroundResource(R.color.colorGreen);
                    }

//                    nAnswerView.setText(nAnswer);

                }
            }
        });

    }

    private void updatequestion() {

        nQuestionView.setText(netLibrary.getQuestion(nQuestionNumber));
        nChoice1.setText(netLibrary.getChoice1(nQuestionNumber));
        nChoice2.setText(netLibrary.getChoice2(nQuestionNumber));
        nChoice3.setText(netLibrary.getChoice3(nQuestionNumber));
        nChoice4.setText(netLibrary.getChoice4(nQuestionNumber));
        nAnswer = netLibrary.getCorrectAnswers(nQuestionNumber);
        nQuestionNumber++;
    }





    private void updateScore(int b) {
        nScoreView.setText("" + nScore);
    }
}

class netlibrary {
    private String nQuestions[] = {"\n" +
            "Which of the following services use TCP? \n" +
            "1. DHCP\n" +
            "2. SMTP\n" +
            "3. HTTP\n" +
            "4. TFTP\n" +
            "5. FTP",
            "You want to implement a mechanism that automates the IP configuration, including IP address, subnet mask, default gateway, and DNS information. Which protocol will you use to accomplish this?",
                    "Which of the following is private IP address?",
            "Which WAN encapsulations can be configured on an asynchronous serial connection?\n" +
                    "1. PPP\n" +
                    "2. ATM\n" +
                    "3. HDLC\n" +
                    "4. SDLC\n" +
                    "5. Frame Relay",
            "Which statement(s) about IPv6 addresses are true? \n"+
            "1. Leading zeros are required.\n" +
            "2. Two colons (::) are used to represent successive hexadecimal fields of zeros.\n" +
            "3. Two colons (::) are used to separate fields.\n" +
            "4. A single interface will have multiple IPv6 addresses of different types.",
    "In which circumstance are multiple copies of the same unicast frame likely to be transmitted in a switched LAN?",
            "What is the frequency range of the IEEE 802.11a standard?",
     "You have a Cisco mesh network. What protocol allows multiple APs to connect with many redundant connections between nodes?",
    "The method of communication in which transmission takes place in both directions, but only one direction at a time is called",
    "Error detection at the data link level is achieved by"};
    private String nCorrectAnswers[] = {"2, 3 and 5", "DHCP", "192.168.24.43", "1 and 2","2 and 4","In an improperly implemented redundant topology","5GHz","AWPP","Half Duplex","Cyclic Redundancy Code"};
    private String nChoices[][] = {{"1 and 2", "2, 3 and 5","1, 2 and 4", "1, 3 and 4"},
            {"SMTP", "SNMP", "DHCP", "ARP"},
            {"12.0.0.1", "168.172.19.39", "172.15.14.36", "192.168.24.43"},
            {"1 and 2", "2 and 4", "3, 4 and 5", "All of the above"},
            {"1 and 3","2 and 4","1, 3 and 4","All of the above"},
            {"During high-traffic periods","After broken links are reestablished","When upper-layer protocols require high reliability","In an improperly implemented redundant topology"},
            {"2.4Gbps","5Gbps","2.4GHz","5GHz"},
            {"LWAPP","AWPP","STP","IEEE"},
            {"Simplex","Four wire circuit","Full Duplex","Half Duplex"},
            {"Bit Stuffing","Cyclic Redundancy Code","Hamming Code","Equalization"}};
    public String getQuestion(int a) {
        String question = nQuestions[a];
        return question;
    }

    public String getChoice1(int a) {
        String choice1 = nChoices[a][0];
        return choice1;
    }

    public String getChoice2(int a) {
        String choice2 = nChoices[a][1];
        return choice2;
    }

    public String getChoice3(int a) {
        String choice3 = nChoices[a][2];
        return choice3;
    }

    public String getChoice4(int a) {
        String choice4 = nChoices[a][3];
        return choice4;
    }

    public String getCorrectAnswers(int a) {
        String answer = nCorrectAnswers[a];
        return answer;
    }
}


