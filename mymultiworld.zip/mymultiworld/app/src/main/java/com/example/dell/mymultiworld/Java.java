package com.example.dell.mymultiworld;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.String;

public class Java extends AppCompatActivity {
    private jlibrary njLibrary = new jlibrary();

    private TextView nScoreView;
    private TextView nQuestionView;
    private Button nChoice1;
    private Button nChoice2;
    private Button nChoice3;
    private Button nChoice4;
    private Button nnext;
    //  private TextView nAnswerView;
    private int nScore = 0;
    private int nQuestionNumber = 0;
    private String nAnswer;



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_java_quiz);

        nScoreView = (TextView) findViewById(R.id.Score);
        nQuestionView = (TextView) findViewById(R.id.question);
        nChoice1 = (Button) findViewById(R.id.choice1);
        nChoice2 = (Button) findViewById(R.id.choice2);
        nChoice3 = (Button) findViewById(R.id.choice3);
        nChoice4 = (Button) findViewById(R.id.choice4);
        nnext=(Button)findViewById(R.id.Next);
        //  nAnswerView = (TextView) findViewById(R.id.answer);
        updatequestion();

        nChoice1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (nChoice1.getText() == nAnswer) {

                    nScore = nScore + 1;
                    Toast.makeText(Java.this, "Welldone !! Keep it up :)", Toast.LENGTH_LONG).show();
                    updateScore(nScore);
                    // nAnswerView.setText(nAnswer);
                    nChoice1.setBackgroundResource(R.color.colorGreen);
                }
                else {
                    Toast.makeText(Java.this, "Oops !! Better luck next time :(", Toast.LENGTH_LONG).show();
                    //  nAnswerView.setText(nAnswer);
                    nChoice1.setBackgroundResource(R.color.colorRed);
                    if(nChoice2.getText()==nAnswer){
                        nChoice2.setBackgroundResource(R.color.colorGreen);
                    }

                    if(nChoice3.getText()==nAnswer){
                        nChoice3.setBackgroundResource(R.color.colorGreen);
                    }

                    if(nChoice4.getText()==nAnswer){
                        nChoice4.setBackgroundResource(R.color.colorGreen);
                    }
                }

            }
        });
        nnext.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                if(nQuestionNumber<=9){
                    updatequestion();
                    nChoice2.setBackgroundResource(R.color.lightGrey);
                    nChoice1.setBackgroundResource(R.color.lightGrey);
                    nChoice3.setBackgroundResource(R.color.lightGrey);

                    nChoice4.setBackgroundResource(R.color.lightGrey);}

                else{
                    Intent intent5 = new Intent(Java.this, Main4Activity.class);
                    intent5.putExtra("Score",nScoreView.getText().toString());
                    startActivity(intent5);
                }
                // nAnswerView.setText("   ");
            }
        });

        nChoice2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (nChoice2.getText() == nAnswer) {
                    nScore = nScore + 1;
                    updateScore(nScore);
                    // nAnswerView.setText(" ");
                    nChoice2.setBackgroundResource(R.color.colorGreen);

                    Toast.makeText(Java.this, "Welldone !! Keep it up :)", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(Java.this, "Oops !! Better luck next time :(", Toast.LENGTH_LONG).show();
                    nChoice2.setBackgroundResource(R.color.colorRed);
                    if(nChoice1.getText()==nAnswer){
                        nChoice1.setBackgroundResource(R.color.colorGreen);
                    }

                    if(nChoice3.getText()==nAnswer){
                        nChoice3.setBackgroundResource(R.color.colorGreen);
                    }

                    if(nChoice4.getText()==nAnswer){
                        nChoice4.setBackgroundResource(R.color.colorGreen);
                    }

                    //  nAnswerView.setText(nAnswer);

                }
            }
        });
        nChoice3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (nChoice3.getText() == nAnswer) {
                    nScore = nScore + 1;
                    // nAnswerView.setText(" ");
                    updateScore(nScore);
                    nChoice3.setBackgroundResource(R.color.colorGreen);

                    Toast.makeText(Java.this, "Welldone !! Keep it up :)", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(Java.this, "Oops !! Better luck next time :(", Toast.LENGTH_LONG).show();
                    nChoice3.setBackgroundResource(R.color.colorRed);
                    if(nChoice1.getText()==nAnswer){
                        nChoice1.setBackgroundResource(R.color.colorGreen);
                    }

                    if(nChoice2.getText()==nAnswer){
                        nChoice2.setBackgroundResource(R.color.colorGreen);
                    }

                    if(nChoice4.getText()==nAnswer){
                        nChoice4.setBackgroundResource(R.color.colorGreen);
                    }

                    // nAnswerView.setText(nAnswer);

                }
            }
        });
        nChoice4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (nChoice4.getText() == nAnswer) {
                    nScore = nScore + 1;
                    updateScore(nScore);
                    //  nAnswerView.setText(" ");
                    nChoice4.setBackgroundResource(R.color.colorGreen);

                    Toast.makeText(Java.this, "Welldone !! Keep it up :)", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(Java.this, "Oops !! Better luck next time :(", Toast.LENGTH_LONG).show();
                    nChoice4.setBackgroundResource(R.color.colorRed);
                    if(nChoice1.getText()==nAnswer){
                        nChoice1.setBackgroundResource(R.color.colorGreen);
                    }

                    if(nChoice2.getText()==nAnswer){
                        nChoice2.setBackgroundResource(R.color.colorGreen);
                    }

                    if(nChoice3.getText()==nAnswer){
                        nChoice3.setBackgroundResource(R.color.colorGreen);
                    }

//                    nAnswerView.setText(nAnswer);

                }
            }
        });

    }

    private void updatequestion() {

        nQuestionView.setText(njLibrary.getQuestion(nQuestionNumber));
        nChoice1.setText(njLibrary.getChoice1(nQuestionNumber));
        nChoice2.setText(njLibrary.getChoice2(nQuestionNumber));
        nChoice3.setText(njLibrary.getChoice3(nQuestionNumber));
        nChoice4.setText(njLibrary.getChoice4(nQuestionNumber));
        nAnswer = njLibrary.getCorrectAnswers(nQuestionNumber);
        nQuestionNumber++;
    }





    private void updateScore(int b) {
        nScoreView.setText("" + nScore);
    }
}

class jlibrary {
    private String nQuestions[] = {"Which data type value is returned by all transcendental math functions?",
            "Which of these methods can be used to obtain a static array from an ArrayList object?",
            "Which of these classes are used by character streams for input and output operations?",
            "Which of these keywords must be used to handle the exception thrown by try block in some rational manner?",
            " What is the default value of priority variable MIN_PRIORITY AND MAX_PRIORITY?",
    " Which methods are commonly used in ServerSocket class?",
    "Which is used as an internal buffer and adds more efficiency than to write data directly into a stream. So, as to makes the performance fast?",
    "\n" +
            "What is the output for the below code ?\n" +
            "class A{\n" +
            "      private void printName(){\n" +
            "            System.out.println(\"Value-A\");\n" +
            "      }\n" +
            "}\n" +
            "class B extends A{\n" +
            "      public void printName(){\n" +
            "            System.out.println(\"Name-B\");\n" +
            "      }\n" +
            "}\n" +
            "public class Test{\n" +
            "      public static void main (String[] args){\n" +
            "            B b = new B();\n" +
            "            b.printName();\n" +
            "      }\n" +
            "}",
    "\n" +
            "What is the result of compiling and running the following code?\n" +
            "public class Test{\n" +
            "        public static void main(String[] args){\n" +
            "                int[] a = new int[0];\n" +
            "                System.out.print(a.length);\n" +
            "        }\n" +
            "}",
    "\n" +
            "What could be output of the following fragment of code?\n" +
            "public class Test{\n" +
            "        public static void main(String args[]){ \n" +
            "\t\tString x = \"hellow\";\n" +
            "\t\tint y = 9;\n" +
            "\t\tSystem.out.println(x += y);\n" +
            "        } \n" +
            "}"};
    private String nCorrectAnswers[] = {"double", "Array()", "Writer", "catch","1 & 10","public Socket accept()","BufferedOutputStream","Name-B","0","hellow9"};
    private String nChoices[][] = {{"int", "float", "double", "long"},
            {"Array()", "covertArray()", "toArray()", "covertoArray()"},
            {"InputStream", "Writer", "ReadStream", "InputOutputStream"},
            {"try", "finally", "throw","catch"},
            {"0 & 256","0 & 1","1 & 10","1 & 256"},
            {"public OutputStream getOutputStream()","public Socket accept()","public synchronized void close()","None of the above"},
            {"BufferedOutputStream","ByteArrayOutputStream","BufferedInputStream","ByteArrayInputStream"},
            {"Value-A","Name-B","Value-A Name-B","Compilation fails - private methods can't be override"},
            {"0","Compilation error, arrays cannot be initialized to zero size","Compilation error, it is a.length() not a.length","None of the above"},
            {"Throws an exception as string and int are not compatible for addition","hellow9","Compilation error","None of these"}};
    public String getQuestion(int a) {
        String question = nQuestions[a];
        return question;
    }

    public String getChoice1(int a) {
        String choice1 = nChoices[a][0];
        return choice1;
    }

    public String getChoice2(int a) {
        String choice2 = nChoices[a][1];
        return choice2;
    }

    public String getChoice3(int a) {
        String choice3 = nChoices[a][2];
        return choice3;
    }

    public String getChoice4(int a) {
        String choice4 = nChoices[a][3];
        return choice4;
    }

    public String getCorrectAnswers(int a) {
        String answer = nCorrectAnswers[a];
        return answer;
    }
}

