package com.example.dell.mymultiworld;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class datastructure extends AppCompatActivity {
    private datastructurelibrary ndatastructurelibrary = new datastructurelibrary();

    private TextView nScoreView;
    private TextView nQuestionView;
    private Button nChoice1;
    private Button nChoice2;
    private Button nChoice3;
    private Button nChoice4;
    private Button nnext;
    //  private TextView nAnswerView;
    private int nScore = 0;
    private int nQuestionNumber = 0;
    private String nAnswer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_datastructure);
 nScoreView = (TextView) findViewById(R.id.Score);
         nQuestionView = (TextView) findViewById(R.id.question);
         nChoice1 = (Button) findViewById(R.id.choice1);
         nChoice2 = (Button) findViewById(R.id.choice2);
         nChoice3 = (Button) findViewById(R.id.choice3);
         nChoice4 = (Button) findViewById(R.id.choice4);
         nnext=(Button)findViewById(R.id.Next);
         //  nAnswerView = (TextView) findViewById(R.id.answer);
         updatequestion();

         nChoice1.setOnClickListener(new View.OnClickListener() {
@Override
public void onClick(View view) {

        if (nChoice1.getText() == nAnswer) {

        nScore = nScore + 1;
        Toast.makeText(datastructure.this, "Welldone !! Keep it up :)", Toast.LENGTH_LONG).show();
        updateScore(nScore);
        // nAnswerView.setText(nAnswer);
        nChoice1.setBackgroundResource(R.color.colorGreen);
        }
        else {
        Toast.makeText(datastructure.this, "Oops !! Better luck next time :(", Toast.LENGTH_LONG).show();
        //  nAnswerView.setText(nAnswer);
        nChoice1.setBackgroundResource(R.color.colorRed);
        if(nChoice2.getText()==nAnswer){
        nChoice2.setBackgroundResource(R.color.colorGreen);
        }

        if(nChoice3.getText()==nAnswer){
        nChoice3.setBackgroundResource(R.color.colorGreen);
        }

        if(nChoice4.getText()==nAnswer){
        nChoice4.setBackgroundResource(R.color.colorGreen);
        }
        }

        }
        });



        nnext.setOnClickListener(new View.OnClickListener(){

@Override
public void onClick(View view) {
        if(nQuestionNumber<=9){
        updatequestion();
        nChoice2.setBackgroundResource(R.color.lightGrey);
        nChoice1.setBackgroundResource(R.color.lightGrey);
        nChoice3.setBackgroundResource(R.color.lightGrey);
        nChoice4.setBackgroundResource(R.color.lightGrey);}

        else{
        Intent intent5 = new Intent(datastructure.this, Main4Activity.class);
        intent5.putExtra("Score",nScoreView.getText().toString());
        startActivity(intent5);

        }
        // nAnswerView.setText("   ");
        }
        });

        nChoice2.setOnClickListener(new View.OnClickListener() {
@Override
public void onClick(View view) {

        if (nChoice2.getText() == nAnswer) {
        nScore = nScore + 1;
        updateScore(nScore);
        // nAnswerView.setText(" ");
        nChoice2.setBackgroundResource(R.color.colorGreen);

        Toast.makeText(datastructure.this, "Welldone !! Keep it up :)", Toast.LENGTH_LONG).show();
        } else {
        Toast.makeText(datastructure.this, "Oops !! Better luck next time :(", Toast.LENGTH_LONG).show();
        nChoice2.setBackgroundResource(R.color.colorRed);
        if(nChoice1.getText()==nAnswer){
        nChoice1.setBackgroundResource(R.color.colorGreen);
        }

        if(nChoice3.getText()==nAnswer){
        nChoice3.setBackgroundResource(R.color.colorGreen);
        }

        if(nChoice4.getText()==nAnswer){
        nChoice4.setBackgroundResource(R.color.colorGreen);
        }

        //  nAnswerView.setText(nAnswer);

        }
        }
        });
        nChoice3.setOnClickListener(new View.OnClickListener() {
@Override
public void onClick(View view) {

        if (nChoice3.getText() == nAnswer) {
        nScore = nScore + 1;
        // nAnswerView.setText(" ");
        updateScore(nScore);
        nChoice3.setBackgroundResource(R.color.colorGreen);

        Toast.makeText(datastructure.this, "Welldone !! Keep it up :)", Toast.LENGTH_LONG).show();
        } else {
        Toast.makeText(datastructure.this, "Oops !! Better luck next time :(", Toast.LENGTH_LONG).show();
        nChoice3.setBackgroundResource(R.color.colorRed);
        if(nChoice1.getText()==nAnswer){
        nChoice1.setBackgroundResource(R.color.colorGreen);
        }

        if(nChoice2.getText()==nAnswer){
        nChoice2.setBackgroundResource(R.color.colorGreen);
        }

        if(nChoice4.getText()==nAnswer){
        nChoice4.setBackgroundResource(R.color.colorGreen);
        }

        // nAnswerView.setText(nAnswer);

        }
        }
        });
        nChoice4.setOnClickListener(new View.OnClickListener() {
@Override
public void onClick(View view) {

        if (nChoice4.getText() == nAnswer) {
        nScore = nScore + 1;
        updateScore(nScore);
        //  nAnswerView.setText(" ");
        nChoice4.setBackgroundResource(R.color.colorGreen);

        Toast.makeText(datastructure.this, "Welldone !! Keep it up :)", Toast.LENGTH_LONG).show();
        } else {
        Toast.makeText(datastructure.this, "Oops !! Better luck next time :(", Toast.LENGTH_LONG).show();
        nChoice4.setBackgroundResource(R.color.colorRed);
        if(nChoice1.getText()==nAnswer){
        nChoice1.setBackgroundResource(R.color.colorGreen);
        }

        if(nChoice2.getText()==nAnswer){
        nChoice2.setBackgroundResource(R.color.colorGreen);
        }

        if(nChoice3.getText()==nAnswer){
        nChoice3.setBackgroundResource(R.color.colorGreen);
        }

//                    nAnswerView.setText(nAnswer);

        }
        }
        });

        }

private void updatequestion() {

        nQuestionView.setText(ndatastructurelibrary.getQuestion(nQuestionNumber));
        nChoice1.setText(ndatastructurelibrary.getChoice1(nQuestionNumber));
        nChoice2.setText(ndatastructurelibrary.getChoice2(nQuestionNumber));
        nChoice3.setText(ndatastructurelibrary.getChoice3(nQuestionNumber));
        nChoice4.setText(ndatastructurelibrary.getChoice4(nQuestionNumber));
        nAnswer = ndatastructurelibrary.getCorrectAnswers(nQuestionNumber);
        nQuestionNumber++;
        }

private void updateScore(int b) {
        nScoreView.setText("" + nScore);
        }
        }

class datastructurelibrary {
    private String nQuestions[] = {"Which one of the following permutations can be obtained the output using stack assuming that the input is the sequence 1,2,3,4,5 in that order ?", "A sequence of data structures connected together through links are known to be", "A binary search tree whose left subtree and right subtree differ in hight by at most 1 unit is called", "Second most used data structure after array is","Stack is also called as",
            "Linked list are not suitable data structure of which one of the following problems ?",
    "Which of the following ways is a in-order traversal?","A ___________ tree is a tree where for each parent node, there is only one associated child node",
    "Which of the following linked list below have last node of the list pointing to the first node?",
    "A minimum spanning tree is a spanning tree organized so that the total ___________ between nodes is minimized",
    "____________ are used to store information in a matrix form."};
    private String nCorrectAnswers[] = {"3,4,5,2,1", "Linked list", "AVL tree", "Linked List","Last in first out","Binary search","left sub tree-> root->right sub tree","degenerate tree"," circular singly linked list","edge weight","Multidimensional arrays"};
    private String nChoices[][] = {{"3,4,5,2,1", "3,4,5,1,2", "5,4,3,1,2", "1,5,2,3,4"},
            {"Connected list", "Linked list", "Traversed link", "Compound List"},
            {"AVL tree", "Red-black tree", "Lemma tree", "None of the above"},
            {"Queue", "Stack", "Hash table", "Linked List"}, {"Last in first out", "First in last out", "Last in last out", "First in first out"},
            {"Binary search", "Insertion sort", "Radix sort", "Polynomial manipulation"},
            {"Root->left sub tree-> right sub tree", " Root->right sub tree-> left sub tree", "right sub tree-> left sub tree->Root", "left sub tree-> root->right sub tree"},
            {"balanced binary tree","rooted complete binary tree","complete binary tree","degenerate tree"} ,
            {"circular doubly linked list","circular linked list"," circular singly linked list","doubly linked list"},
            {"edge size","edge height","edge width","edge weight"},
            {"Multidimensional arrays","arrays","dimensional arrays","Both a and c"}};

    public String getQuestion(int a) {
        String question = nQuestions[a];
        return question;
    }

    public String getChoice1(int a) {
        String choice1 = nChoices[a][0];
        return choice1;
    }

    public String getChoice2(int a) {
        String choice2 = nChoices[a][1];
        return choice2;
    }

    public String getChoice3(int a) {
        String choice3 = nChoices[a][2];
        return choice3;
    }

    public String getChoice4(int a) {
        String choice4 = nChoices[a][3];
        return choice4;
    }

    public String getCorrectAnswers(int a) {
        String answer = nCorrectAnswers[a];
        return answer;
    }
}
