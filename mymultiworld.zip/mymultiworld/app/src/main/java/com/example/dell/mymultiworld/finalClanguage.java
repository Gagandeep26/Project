package com.example.dell.mymultiworld;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class finalClanguage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_final_clanguage);

        TextView tv=(TextView)findViewById(R.id.ScoreView);
        tv.setText(getIntent().getExtras().getString("Score"));

    }
}
