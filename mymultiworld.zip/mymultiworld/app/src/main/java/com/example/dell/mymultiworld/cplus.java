package com.example.dell.mymultiworld;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class cplus extends AppCompatActivity {
    private cpluslibrary ncLibrary = new cpluslibrary();

    private TextView nScoreView;
    private TextView nQuestionView;
    private Button nChoice1;
    private Button nChoice2;
    private Button nChoice3;
    private Button nChoice4;
    private Button nnext;
    //  private TextView nAnswerView;
    private int nScore = 0;
    private int nQuestionNumber = 0;
    private String nAnswer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cplus);
        nScoreView = (TextView) findViewById(R.id.Score);
        nQuestionView = (TextView) findViewById(R.id.question);
        nChoice1 = (Button) findViewById(R.id.choice1);
        nChoice2 = (Button) findViewById(R.id.choice2);
        nChoice3 = (Button) findViewById(R.id.choice3);
        nChoice4 = (Button) findViewById(R.id.choice4);
        nnext=(Button)findViewById(R.id.Next);
        //  nAnswerView = (TextView) findViewById(R.id.answer);
        updatequestion();

        nChoice1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (nChoice1.getText() == nAnswer) {

                    nScore = nScore + 1;
                    Toast.makeText(cplus.this, "Welldone !! Keep it up :)", Toast.LENGTH_LONG).show();
                    updateScore(nScore);
                    // nAnswerView.setText(nAnswer);
                    nChoice1.setBackgroundResource(R.color.colorGreen);
                }
                else {
                    Toast.makeText(cplus.this, "Oops !! Better luck next time :(", Toast.LENGTH_LONG).show();
                    //  nAnswerView.setText(nAnswer);
                    nChoice1.setBackgroundResource(R.color.colorRed);
                    if(nChoice2.getText()==nAnswer){
                        nChoice2.setBackgroundResource(R.color.colorGreen);
                    }

                    if(nChoice3.getText()==nAnswer){
                        nChoice3.setBackgroundResource(R.color.colorGreen);
                    }

                    if(nChoice4.getText()==nAnswer){
                        nChoice4.setBackgroundResource(R.color.colorGreen);
                    }
                }

            }
        });
        nnext.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                if(nQuestionNumber<=9){
                    updatequestion();
                    nChoice2.setBackgroundResource(R.color.lightGrey);
                    nChoice1.setBackgroundResource(R.color.lightGrey);
                    nChoice3.setBackgroundResource(R.color.lightGrey);
                    nChoice4.setBackgroundResource(R.color.lightGrey);}

                else{
                    Intent intent5 = new Intent(cplus.this, Main4Activity.class);
                    intent5.putExtra("Score",nScoreView.getText().toString());
                    startActivity(intent5);

                }
                // nAnswerView.setText("   ");
            }
        });
        nChoice2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (nChoice2.getText() == nAnswer) {
                    nScore = nScore + 1;
                    updateScore(nScore);
                    // nAnswerView.setText(" ");
                    nChoice2.setBackgroundResource(R.color.colorGreen);

                    Toast.makeText(cplus.this, "Welldone !! Keep it up :)", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(cplus.this, "Oops !! Better luck next time :(", Toast.LENGTH_LONG).show();
                    nChoice2.setBackgroundResource(R.color.colorRed);
                    if(nChoice1.getText()==nAnswer){
                        nChoice1.setBackgroundResource(R.color.colorGreen);
                    }

                    if(nChoice3.getText()==nAnswer){
                        nChoice3.setBackgroundResource(R.color.colorGreen);
                    }

                    if(nChoice4.getText()==nAnswer){
                        nChoice4.setBackgroundResource(R.color.colorGreen);
                    }

                    //  nAnswerView.setText(nAnswer);

                }
            }
        });
        nChoice3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (nChoice3.getText() == nAnswer) {
                    nScore = nScore + 1;
                    // nAnswerView.setText(" ");
                    updateScore(nScore);
                    nChoice3.setBackgroundResource(R.color.colorGreen);

                    Toast.makeText(cplus.this, "Welldone !! Keep it up :)", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(cplus.this, "Oops !! Better luck next time :(", Toast.LENGTH_LONG).show();
                    nChoice3.setBackgroundResource(R.color.colorRed);
                    if(nChoice1.getText()==nAnswer){
                        nChoice1.setBackgroundResource(R.color.colorGreen);
                    }

                    if(nChoice2.getText()==nAnswer){
                        nChoice2.setBackgroundResource(R.color.colorGreen);
                    }

                    if(nChoice4.getText()==nAnswer){
                        nChoice4.setBackgroundResource(R.color.colorGreen);
                    }

                    // nAnswerView.setText(nAnswer);

                }
            }
        });
        nChoice4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (nChoice4.getText() == nAnswer) {
                    nScore = nScore + 1;
                    updateScore(nScore);
                    //  nAnswerView.setText(" ");
                    nChoice4.setBackgroundResource(R.color.colorGreen);

                    Toast.makeText(cplus.this, "Welldone !! Keep it up :)", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(cplus.this, "Oops !! Better luck next time :(", Toast.LENGTH_LONG).show();
                    nChoice4.setBackgroundResource(R.color.colorRed);
                    if(nChoice1.getText()==nAnswer){
                        nChoice1.setBackgroundResource(R.color.colorGreen);
                    }

                    if(nChoice2.getText()==nAnswer){
                        nChoice2.setBackgroundResource(R.color.colorGreen);
                    }

                    if(nChoice3.getText()==nAnswer){
                        nChoice3.setBackgroundResource(R.color.colorGreen);
                    }

//                    nAnswerView.setText(nAnswer);

                }
            }
        });

    }

    private void updatequestion() {

        nQuestionView.setText(ncLibrary.getQuestion(nQuestionNumber));
        nChoice1.setText(ncLibrary.getChoice1(nQuestionNumber));
        nChoice2.setText(ncLibrary.getChoice2(nQuestionNumber));
        nChoice3.setText(ncLibrary.getChoice3(nQuestionNumber));
        nChoice4.setText(ncLibrary.getChoice4(nQuestionNumber));
        nAnswer = ncLibrary.getCorrectAnswers(nQuestionNumber);
        nQuestionNumber++;
    }





    private void updateScore(int b) {
        nScoreView.setText("" + nScore);
    }
}

class cpluslibrary {
    private String nQuestions[] = {"Which of the following statements is correct?",
            "Which of the following concepts means determining at runtime what method to invoke?",
            "Which of the following concept of oops allows compiler to insert arguments in a function call if it is not specified?",
            "Which of the following statements is correct in C++ ?",
    "Which of the following is used to make an abstract class?",
    "Which one of the following is the correct way to declare a pure virtual function?",
    "Which of the following factors supports the statement that reusability is a desirable feature of a language?",
    " What is the output of the following program?\n" +
            "\n" +
            "#include<iostream>\n" +
            "\n" +
            "using namespace std;\n" +
            "void f() {\n" +
            "   cout<<\"Hello\"<<endl;\n" +
            "}\n" +
            "main() {\n" +
            "}",
    " What is the full form of STL?",
            "What is the output of this program?\n" +
            "#include < iostream >\n" +
            "using namespace std;\n" +
            "int main ()\n" +
            "{\n" +
            "int i;\n" +
            "cout << \"Please enter an integer value: \";\n" +
            "cin >> i + 4;\n" +
            "return 0;}"};
    private String nCorrectAnswers[] = {"Derived class pointer cannot point to base class.", "Dynamic binding", "Default arguments","Structures can have functions as members.","Making at least one member function as pure virtual function.","virtual void Display(void) = 0;","Both A and B.","No output","Standard template library.","Error"};
    private String nChoices[][] = {{"Base class pointer cannot point to derived class.", "Derived class pointer cannot point to base class.", "Pointer to derived class cannot be created.", "Pointer to base class cannot be created."},
            {"Data hiding", "Dynamic Typing", "Dynamic binding", "Dynamic loading"},
            {"Call by value", "Call by reference", "Default arguments", "Call by pointer"},
            {"Classes cannot have data as protected members.", "Structures can have functions as members.", "Class members are public by default.","Structure members are private by default."},
            {"Declaring it abstract using static keyword.","Declaring it abstract using virtual keyword.","Making at least one member function as virtual function.","Making at least one member function as pure virtual function."},
            {"virtual void Display(void){0};","virtual void Display = 0;","virtual void Display(void) = 0;","void Display(void) = 0;"},
            {"It decreases the testing time.","It lowers the maintenance cost.","It reduces the compilation time.","Both A and B."},
            {"No output","Error, as the function is not called","Error, as the function is defined without its declaration"," Error, as the main() function is left empty"},
            {"Standard template library.","System template library.","Standard topics library.","None of the above"},
            {"73","your value + 4","Error","None of the mentioned"}};

    public String getQuestion(int a) {
        String question = nQuestions[a];
        return question;
    }

    public String getChoice1(int a) {
        String choice1 = nChoices[a][0];
        return choice1;
    }

    public String getChoice2(int a) {
        String choice2 = nChoices[a][1];
        return choice2;
    }

    public String getChoice3(int a) {
        String choice3 = nChoices[a][2];
        return choice3;
    }

    public String getChoice4(int a) {
        String choice4 = nChoices[a][3];
        return choice4;
    }

    public String getCorrectAnswers(int a) {
        String answer = nCorrectAnswers[a];
        return answer;
    }
}

